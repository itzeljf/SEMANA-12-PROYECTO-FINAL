﻿using Proyecto_Simulacion;
using System;


Equipos[,] arrayequipos = new Equipos[8, 4];

opciones:
Console.WriteLine("Menú:\nSeleccione una opción seleccionando el número\n");
Console.WriteLine("1. Ingresar equipos.");
Console.WriteLine("2. Editar Equipos.");
Console.WriteLine("3. Mostrar Información ingresada.");
Console.WriteLine("4. Iniciar Simulación.");
Console.WriteLine("5. Salir.\n");

try
{
    int opcion_menu = int.Parse(Console.ReadLine());
    switch (opcion_menu)
    {
        case 1:
            int i, j;
            for(i = 0; i < 8; i++)
            {

                for(j = 0; j < 4; j++)
                {

                    arrayequipos[i, j] = new Equipos();
                    Console.WriteLine("Ingrese el nombre del equipo: ");
                    arrayequipos[i, j].Nombre_Equipo = Console.ReadLine();

                    do
                    {
                        Console.WriteLine("Ingrese la cantidad de partidos ganados: ");
                        arrayequipos[i, j].Partidos_ganados = int.Parse(Console.ReadLine());
                        if (arrayequipos[i, j].Partidos_ganados < 0 || arrayequipos[i, j].Partidos_ganados > 4) Console.WriteLine("Error al ingresar los partidos ganados");
                        else sumatoria_partidos();

                    } while (arrayequipos[i, j].Partidos_empatados < 0 || arrayequipos[i, j].Partidos_ganados > 4);

                    do
                    {
                        Console.WriteLine("Ingrese la cantidad de partidos empatados");
                        arrayequipos[i, j].Partidos_empatados = int.Parse(Console.ReadLine());
                        if (arrayequipos[i, j].Partidos_empatados < 0 || arrayequipos[i, j].Partidos_empatados > 4) Console.WriteLine("Error! El valor debe de estar entre 0 y 4");
                        else sumatoria_partidos();
                    } while (arrayequipos[i, j].Partidos_empatados < 0 || arrayequipos[i, j].Partidos_empatados > 4);

                    do
                    {
                        Console.WriteLine("Ingrese la cantidad de partidos perdidos");
                        arrayequipos[i, j].Partidos_perdidos = int.Parse(Console.ReadLine());
                        if (arrayequipos[i, j].Partidos_perdidos < 0 || arrayequipos[i, j].Partidos_perdidos > 4) Console.WriteLine("Error! El valor debe de estar entre 0 y 4");
                        else sumatoria_partidos();
                    } while (arrayequipos[i, j].Partidos_perdidos < 0 || arrayequipos[i, j].Partidos_perdidos > 4);
                }
            }

        break;

        case 2:
            Console.WriteLine("Haz seleccionado ingresar equipos. Presiona cualquier tecla para continuar.");
            Console.ReadKey();
            Console.Clear();

            Console.WriteLine("Qué número de equipo quieres editar?");
            int opcion_equipo = int.Parse(Console.ReadLine());
            if (opcion_equipo < 8 || opcion_equipo >= 0)
            {
                Console.WriteLine("Este número de equipo no existe. Presione cualquier tecla para continuar.");
                Console.ReadKey();
                Console.Clear();
                goto opciones;
            }
            for (i = 0; i < 8; i++)
            {


                for (j = 0; j < 4; j++)
                {
                    Console.WriteLine("Ingrese los datos del equipo [ " + opcion_equipo + " ] :");
                    arrayequipos[opcion_equipo, j].Nombre_Equipo = Convert.ToString(Console.ReadLine());
                    do
                    {
                        Console.WriteLine("Ingrese la cantidad de partidos ganados de ese equipo: ");
                        arrayequipos[opcion_equipo, j].Partidos_ganados = int.Parse(Console.ReadLine());
                        if (arrayequipos[i, j].Partidos_ganados < 0 || arrayequipos[i, j].Partidos_ganados > 4) Console.WriteLine("Error al ingresar los partidos ganados");
                        else sumatoria_partidos();
                    } while (arrayequipos[i, j].Partidos_ganados < 0 || arrayequipos[i, j].Partidos_ganados > 4);

                    do
                    {
                        Console.WriteLine("Ingrese la cantidad de partidos empatados de ese equipo: ");
                        arrayequipos[opcion_equipo, j].Partidos_empatados = int.Parse(Console.ReadLine());
                        if (arrayequipos[i, j].Partidos_empatados > 0 || arrayequipos[i, j].Partidos_empatados < 4) Console.WriteLine("Error al ingresar los partidos ganados");
                        else sumatoria_partidos();
                    } while (arrayequipos[i, j].Partidos_empatados > 0 || arrayequipos[i, j].Partidos_empatados < 4);

                    do
                    {
                        Console.WriteLine("Ingrese la cantidad de partidos perdidos de ese equipo: ");
                        arrayequipos[opcion_equipo, j].Partidos_perdidos = int.Parse(Console.ReadLine());
                        if (arrayequipos[i, j].Partidos_empatados > 0 || arrayequipos[i, j].Partidos_empatados < 4) Console.WriteLine("Error al ingresar los partidos ganados");
                        else sumatoria_partidos();
                    } while (arrayequipos[i, j].Partidos_perdidos > 0 || arrayequipos[i, j].Partidos_perdidos < 4);
                    
                }
            }
            break;

        case 3:
            Console.WriteLine("Haz seleccionado imprimir equipos. Presiona cualquier tecla para continuar.");
            Console.ReadKey();
            Console.Clear();

            imprimir_equipos();
            break;

        case 4:
            Console.WriteLine("Comenzamos la simulación");
            Console.ReadKey();

            Random equipo = new Random();
            
                int equipo1 = equipo.Next(0,7);
                int equipo2 = equipo.Next(0, 7);
                int equipo3 = equipo.Next(0, 7);
                int equipo4 = equipo.Next(0, 7);
                int equipo5 = equipo.Next(0, 7);
                int equipo6 = equipo.Next(0, 7);
                int equipo7 = equipo.Next(0, 7);
                int equipo8 = equipo.Next(0, 7);

            if (equipo1 == equipo2) Console.WriteLine("MISMO EQUIPO ENFRENTADO, VUELVA A INTENTARLO");
                else Console.WriteLine("La llave 1 es el equipo: " + equipo1 + " contra el equipo: " + equipo2);

            if (equipo3 == equipo4) Console.WriteLine("MISMO EQUIPO ENFRENTADO, VUELVA A INTENTARLO");
            else Console.WriteLine("La llave 2 es el equipo: " + equipo3 + " contra el equipo: " + equipo4);

            if (equipo5 == equipo6) Console.WriteLine("MISMO EQUIPO ENFRENTADO, VUELVA A INTENTARLO");
            else Console.WriteLine("La llave 3 es el equipo: " + equipo4 + " contra el equipo: " + equipo5);

            if (equipo7 == equipo8) Console.WriteLine("MISMO EQUIPO ENFRENTADO, VUELVA A INTENTARLO");
            else Console.WriteLine("La llave 4 es el equipo: " + equipo5 + " contra el equipo: " + equipo8);

            break;

        case 5:
            Console.WriteLine("Ha elegido salir, hasta pronto. Presione cualquier tecla para cerrar.");
            Console.ReadKey();
            return;
            
        default:Console.WriteLine("Opción no válida, vuelva a intentar. Presione cualquier tecla para continuar.");
            Console.ReadKey();
            Console.Clear();
            goto opciones;
            

    }

}
catch (Exception error)
{
    Console.WriteLine(error);
    Console.ReadKey();
    Console.Clear();
    goto opciones;
}

void imprimir_equipos()
{
    int contador = 1;
    for (int i = 0; i < 8; i++)
    { 
        for (int j = 0; j < 4; j++)
        {
            Console.WriteLine("Equipo [ " + contador + "] :\nNombre: " + arrayequipos[i, j].Nombre_Equipo);
            Console.WriteLine("Partidos Ganados: " + arrayequipos[i, j].Partidos_ganados);
            Console.WriteLine("Partidos Empatados: " + arrayequipos[i, j].Partidos_empatados);
            Console.WriteLine("Partidos Perdidos: " + arrayequipos[i, j].Partidos_perdidos);
            Console.WriteLine("-------------------------------------------------------------------\n\r");
        }
        contador++;
    }
}

string sumatoria_partidos()
{
    int sumatoria = 0;
    string answer = "";
    for(int i = 0; i < 8; i++)
    {
        for(int j = 0; j < 4; j++)
        {
            arrayequipos[i, j] = new Equipos();
            sumatoria = arrayequipos[i, j].Partidos_empatados + arrayequipos[i, j].Partidos_ganados + arrayequipos[i, j].Partidos_perdidos;
            if (sumatoria > 4) answer = "La suma del total de partidos no debe exceder de 4!";
        }
    }
  
    return answer;
}

int goles_favor()
{
    Random random = new Random();
    int favor = random.Next(0,10);
    return favor;
}

int goles_contra()
{
    Random r = new Random();
    int contra = r.Next(0,10);
    return contra;
}